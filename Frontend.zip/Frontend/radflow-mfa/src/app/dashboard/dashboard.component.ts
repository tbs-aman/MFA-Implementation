import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {

  constructor(private readonly router: Router) {}

  navigateToAdminMfaLogs(): void {
    this.router.navigate(['/admin-mfa-logs']);
  }

  navigateToAdminMfa(): void {
    this.router.navigate(['/admin-mfa-settings']);
  }

  navigateToMfaSetting(): void {
    this.router.navigate(['/mfa-settings']);
  }

  logout(): void {
    localStorage.clear();
    this.router.navigate(['/login']);
  }
}

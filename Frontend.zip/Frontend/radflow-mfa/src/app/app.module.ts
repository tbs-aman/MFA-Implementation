import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RouterModule } from '@angular/router';
import { MfaSettingsComponent } from './mfa-settings/mfa-settings.component';
import { AppRoutingModule } from './app.routes';
import { HttpClientModule } from '@angular/common/http';
import { AdminMfaSettingsComponent } from './admin-mfa-settings/admin-mfa-settings.component';
import { AdminMfaLogsComponent } from './admin-mfa-logs/admin-mfa-logs.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';



@Injectable()
export class BaseUrlInterceptor implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler) {
    const baseUrl = 'https://localhost:7114/api';
    const modifiedReq = req.clone({ url: `${baseUrl}${req.url}` });
    return next.handle(modifiedReq);
  }
}

@NgModule({
  declarations: [AppComponent, LoginComponent, MfaSettingsComponent, AdminMfaSettingsComponent, AdminMfaLogsComponent, DashboardComponent],
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule,
  ],
  providers: [
    provideAnimationsAsync(),
    { provide: HTTP_INTERCEPTORS, useClass: BaseUrlInterceptor, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

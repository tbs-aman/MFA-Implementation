import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MfaSettingsComponent } from './mfa-settings/mfa-settings.component';
import { AdminMfaSettingsComponent } from './admin-mfa-settings/admin-mfa-settings.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AdminMfaLogsComponent } from './admin-mfa-logs/admin-mfa-logs.component';
import { AuthGuard } from './auth.guard';

export const routes: Routes = [
  { redirectTo: 'login', path: '', pathMatch: 'full' },
  { component: LoginComponent, path: 'login' },
  { component: AdminMfaSettingsComponent, path: 'admin-mfa-settings',canActivate: [AuthGuard] },
  { component: DashboardComponent, path: 'dashboard',canActivate: [AuthGuard] },
  { component: AdminMfaLogsComponent, path: 'admin-mfa-logs',canActivate: [AuthGuard] },
  { component: MfaSettingsComponent, path: 'mfa-settings',canActivate: [AuthGuard] },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {
}

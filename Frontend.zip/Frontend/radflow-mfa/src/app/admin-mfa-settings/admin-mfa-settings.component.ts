import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { LogService } from '../service/log-service.service';

/**
 * Component responsible for managing MFA (Multi-Factor Authentication) settings for admin users.
 * Provides functionality to fetch users and toggle their MFA status.
 */
@Component({
  selector: 'app-admin-mfa-settings',
  templateUrl: './admin-mfa-settings.component.html',
  styleUrls: ['./admin-mfa-settings.component.css']
})
export class AdminMfaSettingsComponent {
  /**
   * List of users fetched from the backend.
   * Each user object contains user details including MFA status.
   */
  users: any[] = [];
  Message: string = ''; // Variable to store error messages

  /**
   * Constructor to initialize the component.
   * Fetches the list of users from the backend upon initialization.
   * 
   * @param http - Angular's HttpClient service for making HTTP requests.
   */
  constructor(private http: HttpClient,private router: Router, private logService: LogService) {
    this.fetchUsers();
  }

  /**
   * Fetches the list of users from the backend API.
   * Populates the `users` array with the response data.
   * Logs an error message to the console if the request fails.
   */
  fetchUsers() {
    this.http.get('/admin/users').subscribe(
      (response: any) => {
        this.users = response;
      },
      error => {
        console.error('Failed to fetch users:', error);
      }
    );
  }

  /**
   * Toggles the MFA status for a specific user.
   * Sends a POST request to the backend API to update the user's MFA status.
   * Updates the user's MFA status locally upon success.
   * Logs an error message to the console if the request fails.
   * 
   * @param user - The user object whose MFA status needs to be toggled.
   */
  toggleMfa(user: any) {
    const updatedStatus = !user.mfaEnabled;
    const method = user.mfaMethod;
    const userId = user.userId;
    this.http.post('/MfaSettings/' + userId, { mfaEnabled: updatedStatus, mfaMethod: method }).subscribe((response: any) => {
      console.log('MFA settings updated successfully');
      user.mfaEnabled = updatedStatus; // Update the local user object with the new MFA status
      let logRequest = {
        userId: userId,
        action: 'MFA Settings ' + (updatedStatus ? 'Enabled' : 'Disabled') + ' using ' + method + ' method',
        timestamp: new Date()
      }
      this.logService.addLog(logRequest);
      this.successMessage('MFA settings updated successfully');
    });
  }

  
  successMessage(message: string) {
    this.Message = message;
    setTimeout(() => {
      this.Message = '';
    }, 2000); // Clear message after 3 seconds
  }


  backButton() {
    // Logic to navigate back to the previous page or perform any other action
    console.log('Back button clicked');
    this.router.navigate(['/dashboard']);
  }
}
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMfaSettingsComponent } from './admin-mfa-settings.component';

describe('AdminMfaSettingsComponent', () => {
  let component: AdminMfaSettingsComponent;
  let fixture: ComponentFixture<AdminMfaSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminMfaSettingsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AdminMfaSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminMfaLogsComponent } from './admin-mfa-logs.component';

describe('AdminMfaLogsComponent', () => {
  let component: AdminMfaLogsComponent;
  let fixture: ComponentFixture<AdminMfaLogsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminMfaLogsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AdminMfaLogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

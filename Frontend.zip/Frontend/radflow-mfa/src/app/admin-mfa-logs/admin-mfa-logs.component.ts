import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

// Decorator to define the component metadata
@Component({
  selector: 'app-admin-mfa-logs', // The component's selector used in HTML
  templateUrl: './admin-mfa-logs.component.html', // Path to the component's HTML template
  styleUrls: ['./admin-mfa-logs.component.css'] // Path to the component's CSS styles
})
export class AdminMfaLogsComponent {
  // Array to store the logs fetched from the backend
  logs: any[] = [];

  // Injecting HttpClient service for making HTTP requests
  constructor(private http: HttpClient,private router: Router) {
    // Fetch logs when the component is initialized
    this.fetchLogs();
  }

  // Method to fetch MFA logs from the backend API
  fetchLogs() {
    this.http.get('/admin/mfa-logs').subscribe(
      (response: any) => {
        // Assign the fetched logs to the `logs` array
        this.logs = response;
      },
      error => {
        // Log an error message if the API call fails
        console.error('Failed to fetch logs:', error);
      }
    );
  }

  backButton() {
    // Logic to navigate back to the previous page or perform any other action
    console.log('Back button clicked');
    this.router.navigate(['/dashboard']);
  }
}
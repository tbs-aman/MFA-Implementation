import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subscription } from 'rxjs';

/**
 * Service responsible for handling logging operations.
 * Provides functionality to send log data to the server.
 * 
 * @example
 * const log = { message: 'User logged in', level: 'info' };
 * logService.addLog(log);
 */
@Injectable({
  providedIn: 'root'
})
export class LogService {

  /**
   * Initializes the LogService with the required dependencies.
   * 
   * @param http - The HttpClient instance used for making HTTP requests.
   */
  constructor(private readonly http: HttpClient) { }

  /**
   * Sends a log entry to the server for storage.
   * 
   * @param log - The log object containing details such as message and level.
   * @returns A subscription to the HTTP POST request.
   * 
   * @remarks
   * This method logs success or error messages to the console based on the server response.
   * Ensure that the server endpoint `/admin/add-log` is properly configured to handle log entries.
   * 
   * @throws Will log an error to the console if the HTTP request fails.
   */
  addLog(log: any): Subscription {
    return this.http.post('/admin/add-log', log).subscribe({
      next: (response) => {
        console.log('Log added successfully:', response);
      },
      error: (error) => {
        console.error('Error adding log:', error);
      }
    });
  }
}

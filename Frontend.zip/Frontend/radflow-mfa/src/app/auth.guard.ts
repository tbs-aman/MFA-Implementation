import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private readonly router: Router) {}

  canActivate(): boolean {
    const userId = localStorage.getItem('userId'); // Assuming userId is stored in localStorage after login

    if (userId) {
      return true; // Allow access to the page
    } else {
      this.router.navigate(['/login']); // Redirect to login if userId doesn't exist
      return false;
    }
  }
}
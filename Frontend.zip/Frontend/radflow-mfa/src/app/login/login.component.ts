import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

/**
 * The LoginComponent handles the login functionality of the application,
 * including username/password authentication and multi-factor authentication (MFA) via OTP.
 */
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  userId: string = '';

  /**
   * The username entered by the user.
   */
  username: string = '';

  /**
   * The password entered by the user.
   */
  password: string = '';

  /**
   * The one-time password (OTP) entered by the user during the MFA step.
   */
  otp: string = '';

  /**
   * Controls the visibility of the MFA step in the UI.
   * If true, the OTP input step is displayed.
   */
  isOtpStep: boolean = false;


  isAppAuthenticator: boolean = false;

  
  qrCodeImage: string | null = null; // QR Code image (Base64 format)


  /**
   * Stores validation error messages for login fields.
   */
  loginErrorMessage: string = '';

  /**
   * Stores validation error messages for OTP field.
   */
  otpErrorMessage: string = '';

  totp: string = '';
  totpErrorMessage: string = '';
  secretKey: string = '';

  /**
   * Constructor for the LoginComponent.
   * @param router - Angular Router for navigation.
   * @param http - HttpClient for making HTTP requests to the backend.
   */
  constructor(private router: Router, private http: HttpClient) { }

  /**
   * Handles the login process by verifying the username and password with the backend.
   * If MFA is enabled, it transitions to the OTP step; otherwise, it navigates to the dashboard.
   */
  login() {
    // Clear previous error messages
    this.loginErrorMessage = '';

    // Basic validation for username and password
    if (!this.username || !this.password) {
      this.loginErrorMessage = 'Username and password are required.';
      return;
    }

    // Call your backend API to verify username/password
    this.http.post('/auth/login', { username: this.username, password: this.password }).subscribe({
      next: (response: any) => {
        if (response.mfaEnabled) {
          if (response.mfaMethod && response.mfaMethod === 'sms') {
            this.isOtpStep = true; // Display the MFA step
            this.userId = response.userId; // Store userId for later use
          } else if (response.mfaMethod && response.mfaMethod === 'authenticator') {
            this.isAppAuthenticator = true; // Display the MFA step
            this.userId = response.userId; // Store userId for later use
            this.secretKey = response.totpSecret; // Store the secret key for TOTP verification
            this.qrCodeImage = "data:image/png;base64," + response.qrCodeImage;
          }
        } else {
          this.userId = response.userId; // Store userId for later use
          this.loginSuccess(); // Navigate to dashboard if MFA isn't enabled
        }
      },
      error: (error) => {
        console.error('Login failed:', error);
        this.loginErrorMessage = 'Login failed. Please check your credentials and try again.';
      }
    });
  }

  loginSuccess() {
    if (this.userId) {
      localStorage.setItem('userId', this.userId); // Store userId in localStorage
      this.router.navigate(['/dashboard']); // Navigate to dashboard if MFA isn't enabled
    }
  }
  /**
   * Handles the OTP verification process by sending the OTP to the backend for validation.
   * Upon successful verification, it navigates to the dashboard.
   */
  verifyOtp() {
    // Clear previous error messages
    this.otpErrorMessage = '';

    // Basic validation for OTP
    if (!this.otp) {
      this.otpErrorMessage = 'OTP is required.';
      return;
    }

    // Call the backend API to verify the OTP
    this.http.post('/auth/verify-otp', { userId: this.userId, otp: this.otp }).subscribe(
      (response: any) => {
        if (response.success) {
          this.loginSuccess();
        } else {
          this.otpErrorMessage = response.message || 'Invalid OTP. Please try again.';
        }
      },
      error => {
        console.error('OTP verification failed:', error);
        this.otpErrorMessage = 'Invalid OTP. Please try again.';
      }
    );
  }

  verifyTotp() {
    // Call the backend API to verify TOTP
    this.http.post('/auth/verify-totp', { userId: this.userId, totpCode: this.totp, SecretKey: this.secretKey }).subscribe(
      (response: any) => {
        if (response.success) {
          this.loginSuccess();
        } else {
          this.totpErrorMessage = response.message || 'Invalid TOTP code. Please try again.';
        }
      },
      error => {
        console.error('TOTP verification failed:', error);
        this.totpErrorMessage = 'Invalid TOTP code. Please try again.';
      }
    );
  }
}

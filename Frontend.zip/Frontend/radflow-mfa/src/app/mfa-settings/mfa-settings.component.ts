// mfa-settings.component.ts
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LogService } from '../service/log-service.service';

/**
 * Component responsible for managing Multi-Factor Authentication (MFA) settings.
 * Provides functionality to enable or disable MFA and select the preferred authentication method.
 */
@Component({
  selector: 'app-mfa-settings',
  templateUrl: './mfa-settings.component.html',
  styleUrls: ['./mfa-settings.component.css']
})
export class MfaSettingsComponent {

  // Variable to store the user ID, defaulting to '1' if not found in localStorage
  userId: string = localStorage.getItem('userId') ?? '1';

  // Variable to store success or error messages
  message: string = '';

  // Indicates whether MFA is currently enabled, defaults to `false`
  mfaEnabled: boolean = false;

  // Stores the selected MFA method, defaults to `'sms'`
  selectedMethod: string = 'sms';

  constructor(private readonly router: Router, private readonly http: HttpClient, private readonly logService: LogService) {
    this.message = '';
    this.getMfaSettings();
  }

  /**
   * Enables MFA for the user using the selected method.
   * Logs the selected method to the console and updates the backend.
   */
  enableMFA(): void {
    this.mfaEnabled = true;
    console.log(`MFA enabled using: ${this.selectedMethod}`);
    this.updateMFA();
  }

  /**
   * Disables MFA for the user.
   * Logs the action to the console and updates the backend.
   */
  disableMFA(): void {
    this.mfaEnabled = false;
    console.log('MFA disabled');
    this.updateMFA();
  }

  /**
   * Updates MFA settings in the backend.
   * Sends the current MFA status and selected method to the backend API.
   */
  updateMFA(): void {
    const apiUrl = `/MfaSettings/${this.userId}`;
    const payload = { mfaEnabled: this.mfaEnabled, mfaMethod: this.selectedMethod };

    this.http.post(apiUrl, payload).subscribe({
      next: (response: any) => {
        console.log('MFA settings updated successfully');
        const logRequest = {
          userId: this.userId,
          action: `MFA Settings ${this.mfaEnabled ? 'Enabled' : 'Disabled'} using ${this.selectedMethod} method`,
          timestamp: new Date()
        };
        this.logService.addLog(logRequest);
        this.displayMessage('MFA settings updated successfully');
      },
      error: (error) => {
        console.error('Error updating MFA settings:', error);
        this.displayMessage('Failed to update MFA settings');
      }
    });
  }

  /**
   * Displays a success or error message for a short duration.
   * @param message The message to display.
   */
  displayMessage(message: string): void {
    this.message = message;
    setTimeout(() => {
      this.message = '';
    }, 3000); // Clear message after 3 seconds
  }

  /**
   * Fetches the current MFA settings from the backend.
   * Updates the component state with the fetched data.
   */
  getMfaSettings(): void {
    const apiUrl = `/MfaSettings/${this.userId}`;
    this.http.get(apiUrl).subscribe({
      next: (response: any) => {
        this.mfaEnabled = response.mfaEnabled;
        this.selectedMethod = response.mfaMethod;
      },
      error: (error) => {
        console.error('Error fetching MFA settings:', error);
        this.displayMessage('Failed to fetch MFA settings');
      }
    });
  }

  /**
   * Navigates back to the dashboard or previous page.
   */
  backButton(): void {
    console.log('Back button clicked');
    this.router.navigate(['/dashboard']);
  }
}

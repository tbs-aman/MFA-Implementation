﻿using System.Security.Cryptography;
using System.Text;

namespace RadFlowMFA_Backend.Helper
{
    public class EncryptionHelper
    {
        private static readonly string Key = "256"; // Store this key securely (e.g., in environment variables)

        public static string Encrypt(string plainText)
        {
            using (var aes = Aes.Create())
            {
                byte[] keyBytes = Encoding.UTF8.GetBytes(Key);
                if (keyBytes.Length != 32)
                {
                    Array.Resize(ref keyBytes, 32); // Adjust the key size to 32 bytes
                }
                aes.Key = keyBytes;
                aes.IV = new byte[16]; // Initialize vector with zeroes (example)

                using (var encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
                {
                    var plainBytes = Encoding.UTF8.GetBytes(plainText);
                    var encryptedBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                    return Convert.ToBase64String(encryptedBytes);
                }
            }
        }

        public static string Decrypt(string encryptedText)
        {
            using (var aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(Key);
                aes.IV = new byte[16]; // Match the initialization vector used in encryption

                using (var decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                {
                    var encryptedBytes = Convert.FromBase64String(encryptedText);
                    var decryptedBytes = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);
                    return Encoding.UTF8.GetString(decryptedBytes);
                }
            }
        }

    }
}

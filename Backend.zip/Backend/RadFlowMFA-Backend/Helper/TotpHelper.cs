﻿using OtpNet;

namespace RadFlowMFA_Backend.Helper
{
    public class TotpHelper
    {
        public static string GenerateSecretKey()
        {
            var key = KeyGeneration.GenerateRandomKey(20); // Generate a random secret key (20 bytes)
            return Base32Encoding.ToString(key); // Encode the key in Base32 format
        }

        public static string GenerateTotpCode(string secretKey)
        {
            // Decode the secret key from Base32
            byte[] secretKeyBytes = Base32Encoding.ToBytes(secretKey);

            // Create a TOTP object with the decoded secret key
            var totp = new Totp(secretKeyBytes);

            // Generate the current TOTP code
            return totp.ComputeTotp();
        }

        public static bool VerifyTotpCode(string secretKey, string code)
        {
            // Decode the secret key from Base32
            byte[] secretKeyBytes = Base32Encoding.ToBytes(secretKey);

            // Create a TOTP object with the decoded secret key
            var totp = new Totp(secretKeyBytes);

            // Verify the provided TOTP code
            return totp.VerifyTotp(code, out long timeStepMatched, VerificationWindow.RfcSpecifiedNetworkDelay);
        }


    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

[ApiController]
[Route("api/[controller]")]
public class MfaSettingsController : ControllerBase
{
    private readonly IConfiguration _configuration;
    private readonly string connectionString;

    public MfaSettingsController(IConfiguration configuration)
    {
        _configuration = configuration;
        connectionString = _configuration.GetConnectionString("DefaultConnection");
    }

    [HttpGet("{userId}")]
    public IActionResult GetMfaSettings(int userId)
    {
        try
        {
            // Establish a connection to the database using the connection string
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                // Define the query to retrieve MFA settings for the specified user
                string query = "SELECT MFAEnabled, MFAMethod FROM Users WHERE UserId = @UserId";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add the userId parameter to the query
                    command.Parameters.AddWithValue("@UserId", userId);
                    // Execute the query and read the results
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Create an anonymous object to hold the MFA settings
                            var mfaSettings = new
                            {
                                MFAEnabled = reader.GetBoolean(reader.GetOrdinal("MFAEnabled")),
                                MFAMethod = reader.IsDBNull(reader.GetOrdinal("MFAMethod")) ? null : reader.GetString(reader.GetOrdinal("MFAMethod"))
                            };
                            // Return the MFA settings with a 200 OK status
                            return Ok(mfaSettings);
                        }
                        else
                        {
                            // Return a 404 Not Found status if the user is not found
                            return NotFound(new { message = "User not found." });
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Return a 500 Internal Server Error status if an exception occurs
            return StatusCode(500, new { message = "An error occurred.", error = ex.Message });
        }
    }

    [HttpPost("{userId}")]
    public IActionResult UpdateMfaSettings(int userId, [FromBody] UpdateMfaSettingsRequest request)
    {
        try
        {
            // Establish a connection to the database using the connection string
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                // Define the query to update MFA settings for the specified user
                string query = "UPDATE Users SET MFAEnabled = @MFAEnabled, MFAMethod = @MFAMethod WHERE UserId = @UserId";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Add parameters to the query
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.Parameters.AddWithValue("@MFAEnabled", request.MFAEnabled);
                    command.Parameters.AddWithValue("@MFAMethod", string.IsNullOrEmpty(request.MFAMethod) ? (object)DBNull.Value : request.MFAMethod);

                    // Execute the query and get the number of affected rows
                    int rowsAffected = command.ExecuteNonQuery();

                    // Check if any rows were affected
                    if (rowsAffected > 0)
                    {
                        // Return a 200 OK status with a success message
                        return Ok(new { message = "MFA settings updated successfully." });
                    }
                    else
                    {
                        // Return a 404 Not Found status if the user is not found
                        return NotFound(new { message = "User not found." });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            // Return a 500 Internal Server Error status if an exception occurs
            return StatusCode(500, new { message = "An error occurred.", error = ex.Message });
        }
    }
}

public class UpdateMfaSettingsRequest
{
    // Property to indicate if MFA is enabled
    public bool MFAEnabled { get; set; }

    // Property to specify the MFA method
    public string MFAMethod { get; set; }
}

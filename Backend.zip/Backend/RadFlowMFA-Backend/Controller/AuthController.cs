﻿using Microsoft.AspNetCore.Mvc;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using OtpNet;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using QRCoder;
using System.Drawing;
using System.Drawing.Imaging;
using RadFlowMFA_Backend.Helper;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net;
using System.Text;
using System;


[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly string connectionString;
    private readonly string accountSid;
    private readonly string authToken;
    private readonly string twilioPhoneNumber;
    private readonly string issuer;


    public AuthController(IConfiguration _configuration)
    {
        connectionString = _configuration.GetConnectionString("DefaultConnection");
        accountSid = _configuration["Twilio:AccountSid"];
        authToken = _configuration["Twilio:AuthToken"];
        twilioPhoneNumber = _configuration["Twilio:PhoneNumber"];
        issuer = _configuration["appIssuer"];
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginRequest request)
    {
        try
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT top 1 * FROM Users WHERE Username = @Username";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", request.Username);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string passwordHash = reader.IsDBNull(reader.GetOrdinal("PasswordHash")) ? null : reader.GetString(reader.GetOrdinal("PasswordHash"));
                            string requestedPasswor = EncryptionHelper.Encrypt(request.Password);
                            if (requestedPasswor.Equals(passwordHash))
                            {
                                bool mfaEnabled = reader.GetBoolean(reader.GetOrdinal("MFAEnabled"));
                                string mfaMethod = reader.IsDBNull(reader.GetOrdinal("MFAMethod")) ? "" : reader.GetString(reader.GetOrdinal("MFAMethod"));
                                int userId = reader.GetInt32(reader.GetOrdinal("UserId"));
                                string PhoneNumber = reader.IsDBNull(reader.GetOrdinal("PhoneNumber")) ? "" : reader.GetString(reader.GetOrdinal("PhoneNumber"));

                                if (mfaEnabled && mfaMethod != null)
                                {
                                    // Handle MFA Method
                                    if (mfaMethod == "sms")
                                    {
                                        string otp = new Random().Next(100000, 999999).ToString(); // Generate OTP
                                        DateTime expiryTime = DateTime.Now.AddMinutes(5);

                                        SaveOtpToDatabase(userId, otp, expiryTime);

                                        SendSmsOtp(PhoneNumber, otp); // Send OTP

                                        return Ok(new { message = "OTP sent via SMS.", userId, mfaEnabled, mfaMethod });
                                    }
                                    else if (mfaMethod == "authenticator")
                                    {
                                        var totpSecret = GenerateTotpSecret();

                                        SaveTotpSecretToDatabase(userId, totpSecret);

                                        var qrCodeImage = GenerateTotpQrCode(totpSecret, PhoneNumber);

                                        return Ok(new { message = "Enter your TOTP code for verification.", userId, mfaEnabled, mfaMethod, qrCodeImage, totpSecret });
                                    }
                                }
                                else
                                {
                                    return Ok(new { message = "Login successful without MFA.", userId, mfaEnabled, mfaMethod });
                                }
                            }
                            else
                            {
                                return Unauthorized(new { message = "Invalid credentials." });
                            }
                        }
                        else
                        {
                            return Unauthorized(new { message = "Invalid credentials." });
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "An error occurred during login.", error = ex.Message });
        }
        return StatusCode(500, new { message = "An error occurred during login.", error = "" });
    }

    [HttpPost("verify-otp")]
    public IActionResult VerifyOtp([FromBody] VerifyOtpRequest request)
    {
        try
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT OTP FROM Users WHERE UserId = @UserId AND ExpiryTime > GETDATE()"; // Ensure OTP has not expired
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", request.UserId);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string correctOtp = reader.GetString(reader.GetOrdinal("OTP"));

                            if (request.Otp == correctOtp)
                            {
                                return Ok(new { message = "OTP verified successfully.", success = true });
                            }
                            else
                            {
                                return Unauthorized(new { message = "Invalid OTP.", success = false });
                            }
                        }
                        else
                        {
                            return NotFound(new { message = "OTP not found or expired.", success = false });
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "An error occurred during OTP verification.", error = ex.Message });
        }
    }

    [HttpPost("verify-totp")]
    public IActionResult VerifyTotp([FromBody] VerifyTotpRequest request)
    {
        try
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT MFASecret FROM Users WHERE UserId = @UserId";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", request.UserId);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string secretKey = reader.GetString(reader.GetOrdinal("MFASecret"));

                            // Decode the secret key from Base32
                            byte[] secretKeyBytes = Base32Encoding.ToBytes(secretKey);
                            var totp = new Totp(secretKeyBytes);

                            // Verify the TOTP code
                            bool isValid = totp.VerifyTotp(request.TotpCode, out long timeStepMatched, VerificationWindow.RfcSpecifiedNetworkDelay);

                            if (isValid)
                            {
                                return Ok(new { message = "TOTP verified successfully.", success = true });
                            }
                            else
                            {
                                return Unauthorized(new { message = "Invalid TOTP code.", success = false });
                            }
                        }
                        else
                        {
                            return NotFound(new { message = "User not found.", success = false });
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "An error occurred during TOTP verification.", error = ex.Message });
        }
    }

    private string GenerateTotpSecret()
    {
        var key = KeyGeneration.GenerateRandomKey(20); // Generate a random 20-byte key
        return Base32Encoding.ToString(key); // Convert the key to a Base32 string
    }

    private void SaveTotpSecretToDatabase(int userId, string totpSecret)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "UPDATE Users SET MFASecret = @TotpSecret WHERE UserId = @UserId";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@UserId", userId);
                command.Parameters.AddWithValue("@TotpSecret", totpSecret);
                command.ExecuteNonQuery();
            }
        }
    }

    private void SaveOtpToDatabase(int userId, string otp, DateTime expiryTime)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "UPDATE Users SET OTP = @Otp, ExpiryTime = @ExpiryTime WHERE UserId = @UserId";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@UserId", userId);
                command.Parameters.AddWithValue("@Otp", otp);
                command.Parameters.AddWithValue("@ExpiryTime", expiryTime);
                command.ExecuteNonQuery();
            }
        }
    }

    private void SendSmsOtp(string phoneNumber, string otp)
    {
        TwilioClient.Init(accountSid, authToken);
        MessageResource.Create(
            body: $"Your OTP is: {otp}",
            from: new Twilio.Types.PhoneNumber(twilioPhoneNumber),
            to: new Twilio.Types.PhoneNumber("+1" + phoneNumber)
        );
    }

    private string GenerateTotpQrCode(string secretKey, string username)
    {
        var totpUrl = $"otpauth://totp/{issuer}:{username}?secret={secretKey}&issuer={issuer}";

        using var qrGenerator = new QRCodeGenerator();
        using var qrCodeData = qrGenerator.CreateQrCode(totpUrl, QRCodeGenerator.ECCLevel.Q);
        using var qrCode = new PngByteQRCode(qrCodeData);
        byte[] qrCodeBytes = qrCode.GetGraphic(20);

        // Convert the byte array to a Bitmap
        using (MemoryStream ms = new MemoryStream(qrCodeBytes))
        {
            using (Bitmap qrBitmap = new(ms))
            {
                using (MemoryStream outputMs = new MemoryStream())
                {
                    // Save the Bitmap as PNG
                    qrBitmap.Save(outputMs, ImageFormat.Png);
                    return Convert.ToBase64String(outputMs.ToArray());  // Convert to Base64
                }
            }
        }
    }

}



public class LoginRequest
{
    public string Username { get; set; }
    public string Password { get; set; }
}

public class VerifyOtpRequest
{
    public string Otp { get; set; }
    public int UserId { get; set; }
}

public class VerifyTotpRequest
{
    public string SecretKey { get; set; }
    public int UserId { get; set; }
    public string TotpCode { get; set; }
}
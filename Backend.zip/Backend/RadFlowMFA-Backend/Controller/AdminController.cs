﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

[ApiController]
[Route("api/admin")]
public class AdminController : ControllerBase
{
    private readonly IConfiguration _configuration;
    private readonly string connectionString;

    public AdminController(IConfiguration configuration)
    {
        _configuration = configuration;
        connectionString = _configuration.GetConnectionString("DefaultConnection");
    }

    [HttpGet("users")]
    public IActionResult GetUsers()
    {
        try
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT UserId, Username, MFAEnabled, CreatedAt, MFAMethod FROM Users";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        var users = new List<object>();
                        while (reader.Read())
                        {
                            users.Add(new
                            {
                                UserId = reader.GetInt32(reader.GetOrdinal("UserId")),
                                Username = reader.GetString(reader.GetOrdinal("Username")),
                                MFAEnabled = reader.GetBoolean(reader.GetOrdinal("MFAEnabled")),
                                CreatedAt = reader.GetDateTime(reader.GetOrdinal("CreatedAt")),
                                MFAMethod = reader.GetString(reader.GetOrdinal("MFAMethod"))
                            });
                        }
                        return Ok(users);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "An error occurred while fetching users.", error = ex.Message });
        }
    }

    [HttpGet("mfa-logs")]
    public IActionResult GetMfaLogs()
    {
        try
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT MfaLogs.LogId, MfaLogs.UserId, Users.Username, MfaLogs.Action, FORMAT(MfaLogs.Timestamp, 'MM/dd/yyyy HH:mm:ss')  as Timestamp FROM MfaLogs INNER JOIN Users ON MfaLogs.UserId = Users.UserId ORDER BY MfaLogs.Timestamp DESC;";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        var logs = new List<object>();
                        while (reader.Read())
                        {
                            logs.Add(new
                            {
                                LogId = reader.GetInt32(reader.GetOrdinal("LogId")),
                                UserId = reader.GetInt32(reader.GetOrdinal("UserId")),
                                Username = reader.GetString(reader.GetOrdinal("Username")),
                                Action = reader.GetString(reader.GetOrdinal("Action")),
                                Timestamp = reader.GetString(reader.GetOrdinal("Timestamp"))
                            });
                        }
                        return Ok(logs);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "An error occurred while fetching MFA logs.", error = ex.Message });
        }
    }

    [HttpPost("add-log")]
    public IActionResult AddLog([FromBody] AddLogRequest request)
    {
        try
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "INSERT INTO MfaLogs (UserId, Action, Timestamp) VALUES (@UserId, @Action, @Timestamp)";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserId", request.UserId);
                    command.Parameters.AddWithValue("@Action", request.Action);
                    command.Parameters.AddWithValue("@Timestamp", request.Timestamp);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        return Ok(new { message = "Log added successfully." });
                    }
                    else
                    {
                        return BadRequest(new { message = "Failed to add log." });
                    }
                }
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { message = "An error occurred while adding the log.", error = ex.Message });
        }
    }
}

public class AddLogRequest
{
    public int UserId { get; set; }       // ID of the user generating the log
    public string Action { get; set; }   // Log action, e.g., "Successful Verification", "Failed Attempt"
    public DateTime Timestamp { get; set; } // Timestamp of the log
}

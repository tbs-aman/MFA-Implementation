﻿using System;
using OtpNet;
using System.Text;
using RadFlowMFA_Backend.Service.Interfaces;

public class TOTPService : ITOTPService
{
    /// <summary>
    /// Generates a new secret key for a user.
    /// This key should be stored securely and used for generating TOTP codes.
    /// </summary>
    public string GenerateSecretKey()
    {
        byte[] key = KeyGeneration.GenerateRandomKey(20); // 20-byte secret key
        return Base32Encoding.ToString(key);
    }

    /// <summary>
    /// Generates a TOTP code based on the secret key.
    /// This code changes every 30 seconds.
    /// </summary>
    public string GenerateTOTP(string secretKey)
    {
        var keyBytes = Base32Encoding.ToBytes(secretKey);
        var totp = new Totp(keyBytes);
        return totp.ComputeTotp();
    }

    /// <summary>
    /// Validates a TOTP code entered by the user.
    /// Returns true if valid, false otherwise.
    /// </summary>
    public bool ValidateTOTP(string secretKey, string userInputCode)
    {
        var keyBytes = Base32Encoding.ToBytes(secretKey);
        var totp = new Totp(keyBytes);

        return totp.VerifyTotp(userInputCode, out _, new VerificationWindow(1, 1)); // 1-step window for flexibility
    }

    /// <summary>
    /// Generates a QR Code URL to be scanned in Google Authenticator.
    /// </summary>
    public string GenerateQRCodeUri(string userEmail, string secretKey)
    {
        string issuer = "RadFlow360"; // Change to your app name
        return $"otpauth://totp/{issuer}:{userEmail}?secret={secretKey}&issuer={issuer}";
    }
}

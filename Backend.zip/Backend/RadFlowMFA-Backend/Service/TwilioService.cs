﻿using Microsoft.Extensions.Configuration;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using System;
using RadFlowMFA_Backend.Service.Interfaces;

public class TwilioService : ITwilioService
{
    private readonly string _accountSid;
    private readonly string _authToken;
    private readonly string _twilioPhoneNumber;

    public TwilioService(IConfiguration configuration)
    {
        var twilioConfig = configuration.GetSection("Twilio");
        _accountSid = twilioConfig["AccountSid"];
        _authToken = twilioConfig["AuthToken"];
        _twilioPhoneNumber = twilioConfig["PhoneNumber"];

        TwilioClient.Init(_accountSid, _authToken);
    }

    public string GenerateOTP()
    {
        Random random = new Random();
        return random.Next(100000, 999999).ToString();
    }

    public bool SendOTP(string userPhoneNumber, string otp)
    {
        try
        {
            var message = MessageResource.Create(
                to: new PhoneNumber(userPhoneNumber),
                from: new PhoneNumber(_twilioPhoneNumber),
                body: $"Your MFA verification code is: {otp}"
            );

            return message.Status != MessageResource.StatusEnum.Failed;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error sending OTP: {ex.Message}");
            return false;
        }
    }
}

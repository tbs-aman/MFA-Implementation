﻿namespace RadFlowMFA_Backend.Service.Interfaces;

public interface ITwilioService
{
    public string GenerateOTP();
    public bool SendOTP(string userPhoneNumber, string otp);
}

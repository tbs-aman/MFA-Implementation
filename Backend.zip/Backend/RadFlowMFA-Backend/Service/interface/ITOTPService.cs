﻿namespace RadFlowMFA_Backend.Service.Interfaces;

public interface ITOTPService
{
    public string GenerateSecretKey();
    public string GenerateTOTP(string secretKey);
    public bool ValidateTOTP(string secretKey, string userInputCode);
    public string GenerateQRCodeUri(string userEmail, string secretKey);
}
